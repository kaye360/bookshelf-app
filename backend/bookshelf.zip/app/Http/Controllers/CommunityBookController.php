<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CommunityBookController extends Controller
{
    //
}
